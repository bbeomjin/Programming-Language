a = "Hellow~!"
print(a)